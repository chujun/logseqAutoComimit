- 满足CAP理论中的CP
- 强制一致性
- 可用性
  leader选举期间raft集群不可用
- [[raft白皮书]]
- 资料