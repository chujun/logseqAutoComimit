- 快捷键
- 插件
  很多有用的插件
  小众插件
	- jclasslib
	  id:: 62a5a802-1f28-4408-a904-fb87427f26e8
	  作用:可以更直观看到 Class 文件结构
	  ![jclasslib查看Class文件结构效果图.png](../assets/image_1655023417484_0.png)
	  使用:
	  Veiw->Show bytecode with jclasslib
	  ![jclasslib使用方法截图.png](../assets/jclasslib使用方法截图_1655024014157_0.png)
-