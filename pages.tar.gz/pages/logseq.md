- 常见快捷键
  mac
  cmd+shift+p:搜索命令大全
  cmd+k:全文搜索
  cmd+shift+k:当前页搜索