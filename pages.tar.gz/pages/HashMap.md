- 主要步骤
  初始化
  hash定位
  hash冲突
  扩容--->rehash
  链表和红黑树的相互转化 jdk8
  get
  put
  remove
- hash的死循环
- hash线程不安全
- TODO:cj 等并发看完回头梳理