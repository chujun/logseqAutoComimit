- [Java SE Specifications java规范官方文档链接](https://docs.oracle.com/javase/specs/index.html)
- [java语言规范8官方文档链接](https://docs.oracle.com/javase/specs/jls/se8/html/index.html)
- [jvm规范8官方文档链接](https://docs.oracle.com/javase/specs/jvms/se8/html/index.html)
  id:: 628ca746-598e-4db5-b964-7c4a80b26680
-
-